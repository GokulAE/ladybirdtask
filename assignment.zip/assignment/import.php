<?php
session_start();
include("auth.php");
include_once 'dbconfig.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Batman Portal</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" >
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="index.php">Batman Portal</a>
		</div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<?php if (isset($_SESSION['usr_id'])) { ?>
				<li><p class="navbar-text">Signed in as <?php echo $_SESSION['usr_name']; ?></p></li>
				<li><a href="logout.php">Log Out</a></li>
				<?php } else { ?>
				<li><a href="login.php">Login</a></li>
				<li><a href="register.php">Sign Up</a></li>
				<?php } ?>
			</ul>
		</div>
	</div>
</nav>

<!DOCTYPE>
<html>

<head>
	<link rel="stylesheet" href="css/index.css" type="text/css" />

</head>

<?php
if(isset($_POST["submit"]))
{
include'dbconfig.php'; 
 if(!$con){
          die('Could not Connect My Sql:' .mysqli_error());
		  }
          $file = $_FILES['file']['tmp_name'];
          $handle = fopen($file, "r");
          $c = 0;
          while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
                    {
          $que = $filesop[0];
          $option1 = $filesop[1];
          $option2 = $filesop[2];
          $option3 = $filesop[3];
          $option4 = $filesop[4];
          $ans = $filesop[5];
          $sql = "insert into quiz(que,option1,option2,option3,option4,ans) values ('$que','$option1','$option2','$option3','$option4','$ans')";
          $stmt = mysqli_prepare($con,$sql);
          mysqli_stmt_execute($stmt);

         $c = $c + 1;
           }

            if($sql){
               echo "sucess";
             } 
		 else
		 {
            echo "Sorry! Unable to import.";
          }

}
?>

<html>
<body>

<center>
<form enctype="multipart/form-data" method="post" role="form">
    <div class="form-group">
        <label for="exampleInputFile">File Upload</label>
        <input type="file" name="file" id="file" size="150">
        <p class="help-block">Only Excel/CSV File Import.</p>
	 </div>
    <button type="submit" class="btn btn-default" name="submit" value="submit">Upload</button>
		<!--a href="template/template.csv" download> Sample Template</a-->
   
</form>
</center>
</body>
</html>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>

