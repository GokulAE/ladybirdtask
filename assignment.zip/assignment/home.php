<?php
session_start();
include("auth.php");
include'dbconfig.php';
?>

<head>
<body>
<link rel="stylesheet" href="css/index.css" type="text/css" />
<a href="participant.php"><button class="button" name="start" float="left"><span>Result</span></button></a>

<a href="import.php"><button class="button" name="start" float="right"><span>Bulk Upload</span></button></a>
</body>
</head>