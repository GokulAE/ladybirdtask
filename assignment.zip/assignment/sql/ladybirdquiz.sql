-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2020 at 08:20 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ladybirdquiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `id` int(255) NOT NULL,
  `que` text NOT NULL,
  `option1` varchar(222) NOT NULL,
  `option2` varchar(222) NOT NULL,
  `option3` varchar(222) NOT NULL,
  `option4` varchar(222) NOT NULL,
  `ans` varchar(222) NOT NULL,
  `userans` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`id`, `que`, `option1`, `option2`, `option3`, `option4`, `ans`, `userans`) VALUES
(1, 'Which of the following is not a feature of Election system in India?', 'Universal Adult Franchise', 'Secret Voting', 'Scheduled Tribes', 'Communal Electorate', 'Communal Electorate', 'Communal Electorate'),
(2, 'Elections in India for Parliament and State Legislatures are conducted by', 'President', 'State Election Commission', 'Governor', 'Election Commission of India', 'Election Commission of India', 'Election Commission of India'),
(3, 'Members of Election Commission are appointed by', 'President of India', 'Prime Minister of India', 'Chief Justice of India', 'Elected by the people', 'President of India', 'President of India'),
(4, 'Which article of the Indian constitution says that will be an election commission in India?', 'Article 124', 'Article 342', 'Article 324', 'Article 115', 'Article 324', 'Article 324'),
(5, 'The number of seats reserved for scheduled caste in the Lok sabha is:', '59', '79', '89', '99', '79', '79'),
(6, 'Which Articles in the Constitution give provisions for the electoral system in our country', 'Articles 124-128', 'Articles 324-329', 'Articles 256-259', 'Articles 274-279', 'Articles 324-329', 'Articles 324-329'),
(7, 'The elections for Lok Sabha are held every:', '3 years', '4 years', '5 years', '6 years', '5 years', '5 years'),
(8, 'Which is the smallest Lok Sabha Constituency in General Elections by area?', 'Delhi Sadar', 'Mumbai South', 'Kolkata North West', 'Chandni Chowk, Delhi', 'Chandni Chowk, Delhi', 'Chandni Chowk, Delhi'),
(9, 'Members of Election Commission are appointed by', 'President of India', 'Prime Minister of India', 'Chief Justice of India', 'Elected by the people', 'President of India', 'Chief Justice of India'),
(10, 'The elections for Lok Sabha are held every:', '1years', '2 years', '5 years', '3 years', '5 years', '3 years');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(8) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(40) NOT NULL,
  `role` int(10) NOT NULL DEFAULT 1,
  `voted` int(10) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `voted`) VALUES
(1, 'Gokul', 'gokuldarez@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1, 1),
(2, 'Batman', 'admin@batman.com', 'e10adc3949ba59abbe56e057f20f883e', 2, 0),
(3, 'User', 'user@batman.com', '4297f44b13955235245b2497399d7a93', 1, 1),
(4, 'Smith', 'smith@batman.com', '4297f44b13955235245b2497399d7a93', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `voteid` int(100) NOT NULL,
  `id` int(10) NOT NULL,
  `totalanswered` int(100) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`voteid`, `id`, `totalanswered`, `created_at`) VALUES
(37, 1, 6, '2020-09-09 10:59:59.428067'),
(38, 3, 8, '2020-09-09 11:03:04.894905'),
(39, 4, 8, '2020-09-09 11:40:22.697426');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`voteid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vote`
--
ALTER TABLE `vote`
  MODIFY `voteid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
