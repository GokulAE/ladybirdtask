<?php
@ob_start();
session_start();
if(!isset($_SESSION["usr_name"])){
header("Location: login.php");
exit(); }
ob_end_clean();
?>
